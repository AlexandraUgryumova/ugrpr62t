﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;
using Pr6_2.Models;

namespace Pr6_2.Data
{
    public class ClientDB
    {
        private readonly SQLiteConnection connection;
        public ClientDB(string path)
        {
            connection = new SQLiteConnection(path);
            connection.CreateTable<Client>();
        }
        public List<Client> GetClients()
        {
            return connection.Table<Client>().ToList(); 
        }
        public int SaveClient(Client client)
        {
            return connection.Insert(client);
        }
    }
}
