﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Pr6_2.Models
{

    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginPage : ContentPage
    {
        private Picker myPicker;
        private string option = "";
        private Entry usernameEntry;
        private Entry passwordEntry;
        public LoginPage()
        {
            InitializeComponent();
            var welcomeLabel = new Label
            {
                Text = "Добро пожаловать",
                FontSize = Device.GetNamedSize(NamedSize.Large, typeof(Label)),
                HorizontalOptions = LayoutOptions.Center,
                TextColor = Color.Black,
                Margin = new Thickness(0, 0, 0, 40)
            };

            usernameEntry = new Entry
            {
                Placeholder = "Ваш логин",
                HorizontalOptions = LayoutOptions.FillAndExpand,
                StyleId = "styleMe"

            };

            passwordEntry = new Entry
            {
                Placeholder = "Ваш пароль",
                IsPassword = true,
                HorizontalOptions = LayoutOptions.FillAndExpand,
                StyleId = "styleMe",
                Margin = new Thickness(0, -8, 0, 0)
            };

            var rememberMeCheckBox = new CheckBox
            {
                HorizontalOptions = LayoutOptions.Start,
                StyleId = "styleMe2"
            };
            var textRemember = new Label
            {
                Text = "запомнить меня",
                StyleId = "styleMe2",
                HorizontalOptions = LayoutOptions.FillAndExpand,
                Margin = new Thickness(40, -35, 0, 0)
            };
            var RememberBox = new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                Children =
                {
                    rememberMeCheckBox,
                    textRemember
                }
            };
            
            myPicker = new Picker
            {
                Title = "Кто входит?",
                Margin = new Thickness(5, 0, 200, 0),
                TextColor = Color.Black,
                
            };
            myPicker.Items.Add("Клиент");
            myPicker.Items.Add("Работник фирмы");
            myPicker.Items.Add("Поставщик");
            myPicker.SelectedIndexChanged += MyPicker_SelectedIndexChanged;
            



            var signInButton = new Button
            {
                Text = "Войти",
                HorizontalOptions = LayoutOptions.FillAndExpand
            };

            var signInLayout = new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                Children =
                {
                    signInButton,
                    new Label{ Text = "Я забыл!", HorizontalOptions = LayoutOptions.End }
                }
            };

            var errorMessageLabel = new Label
            {
                TextColor = Color.Red,
                HorizontalOptions = LayoutOptions.Center
            };

            signInButton.Clicked += MyButton_Clicked;
            var stackLayout = new StackLayout
            {
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.FillAndExpand,
                Padding = new Thickness(30),
                Children =
                {
                    welcomeLabel,
                    usernameEntry,
                    passwordEntry,
                    myPicker,
                    rememberMeCheckBox,
                    textRemember,
                    signInLayout,
                }
            };
            Content = stackLayout;
        }
        private void MyPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (myPicker.SelectedIndex)
            {
                case 0:
                    option = "Клиент";
                    break;
                case 1:
                    option = "Работник фирмы";
                    break;
                case 2:
                    option = "Поставщик";
                    break;
                default:
                    break;
            }
        }
        private void MyButton_Clicked(object sender, EventArgs e)
        {
                if (string.IsNullOrWhiteSpace(usernameEntry.Text) || string.IsNullOrWhiteSpace(passwordEntry.Text))
                {
                    DisplayAlert("Ошибка входа", "введите логин и пароль", "OK");
                }
                else
                {
                    switch (option)
                    {
                        case "Клиент":
                        var listPage = new ListMebelsForClient();
                            Navigation.PushAsync(listPage);
                            break;
                        case "Работник фирмы":
                        var listPage2 = new NavigationForWorkPage();
                        Navigation.PushAsync(listPage2);
                            break;
                        case "Поставщик":
                        var listPage3 = new ListDetailsForManufacture();
                        Navigation.PushAsync(listPage3);
                            break;
                        default:
                            DisplayAlert("Ошибка входа", "вы не выбрали кем собираетесь входить в систему", "ОК");
                            break;
                    }
                }
        }
    }
}