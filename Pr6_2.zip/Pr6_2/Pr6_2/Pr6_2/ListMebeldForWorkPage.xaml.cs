﻿using Pr6_2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Pr6_2
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ListMebeldForWorkPage : ContentPage
    {
        public ListMebeldForWorkPage()
        {
            InitializeComponent();
            var listview = new MebelItem
            {
                Id = 1,
                Name = "Стул",
                detales = "шурупы",
                Photo = "https://pinskdrev.ru/web/catalogfiles/catalog/offers/Styl_Kontur_614_tabak.jpg",
                Price = 2500,
            };
        }
        
    }
}