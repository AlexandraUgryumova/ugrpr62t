﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace Pr6_2.Models
{
    public class Client
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string FIO { get; set; }
        public double Discount { get; set; }
    }
}
