﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace Pr6_2.Models
{
    public class Zalaz
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public int Polupatel { get; set; }
        public int Count { get; set; }
        public int Mebel { get; set; }
    }
}
