﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Pr6_2
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class NavigationForWorkPage : ContentPage
    {
        public NavigationForWorkPage()
        {
            InitializeComponent();
            var label = new Label()
            {
                Text = "выберите куда вам нужно"
            };
            var buttonMebels = new Button()
            {
                Text = "Мебель"
            };
            buttonMebels.Clicked += (sender, e) =>
            {
                Navigation.PushAsync(new ListMebeldForWorkPage());
            };
            var buttonClients = new Button()
            {
                Text = "Клиенты"
            };
            buttonClients.Clicked += (sender, e) =>
            {
                Navigation.PushAsync(new ListClientsForWorkPage());
            };
            var buttonZakaz = new Button()
            {
                Text = "Заказы"
            };
            buttonZakaz.Clicked += (sender, e) =>
            {
                Navigation.PushAsync(new ListZalazForWorkPage());
            };
            var stackLayout = new StackLayout
            {
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center,
                Orientation = StackOrientation.Vertical,
                Children =
                {
                    label,
                    buttonMebels, 
                    buttonClients,
                    buttonZakaz,
                }
            };
        }
    }
}